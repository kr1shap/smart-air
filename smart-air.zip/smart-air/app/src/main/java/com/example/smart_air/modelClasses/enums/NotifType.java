package com.example.smart_air.modelClasses.enums;

public enum NotifType {
        INVENTORY, TRIAGE, WORSE_DOSE, RAPID_RESCUE, RED_ZONE
}
