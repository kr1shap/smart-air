package com.example.smart_air.helpers;

import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;

import java.time.DayOfWeek;
import java.time.Instant;
import java.time.LocalDate;
import java.time.ZoneId;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * AdherenceCalculator - Calculates controller medication adherence
 * Compares scheduled controller days vs actual usage logs
 */
public class AdherenceCalculator {

    public interface AdherenceCallback {
        void onCalculated(AdherenceResult result);
        void onError(Exception e);
    }

    public static class AdherenceResult {
        public int plannedDays;
        public int completedDays;
        public double adherencePercentage;
        public List<LocalDate> missedDays;

        public AdherenceResult() {
            this.missedDays = new ArrayList<>();
        }

        public String getFormattedPercentage() {
            return String.format("%.1f%%", adherencePercentage);
        }
    }

    /**
     * Calculate adherence for a child over a date range
     * @param childId The child's UID
     * @param fromDate Start date
     * @param toDate End date
     * @param callback Result callback
     */
    public static void calculateAdherence(String childId,
                                          LocalDate fromDate,
                                          LocalDate toDate,
                                          AdherenceCallback callback) {
        FirebaseFirestore db = FirebaseFirestore.getInstance();

        // First, get the child's controller schedule
        db.collection("users")
                .document(childId)
                .get()
                .addOnSuccessListener(userDoc -> {
                    if (!userDoc.exists()) {
                        callback.onError(new Exception("User not found"));
                        return;
                    }

                    // Get schedule (e.g., "MONDAY,WEDNESDAY,FRIDAY" or "DAILY")
                    String schedule = userDoc.getString("controllerSchedule");
                    if (schedule == null || schedule.isEmpty()) {
                        // No schedule set - return empty result
                        AdherenceResult result = new AdherenceResult();
                        result.plannedDays = 0;
                        result.completedDays = 0;
                        result.adherencePercentage = 0.0;
                        callback.onCalculated(result);
                        return;
                    }

                    // Calculate planned days based on schedule
                    List<LocalDate> plannedDates = calculatePlannedDates(schedule, fromDate, toDate);

                    // Now fetch actual controller logs
                    fetchControllerLogs(db, childId, fromDate, toDate, plannedDates, callback);
                })
                .addOnFailureListener(callback::onError);
    }

    /**
     * Calculate which dates the controller was planned based on schedule string
     */
    private static List<LocalDate> calculatePlannedDates(String schedule,
                                                         LocalDate fromDate,
                                                         LocalDate toDate) {
        List<LocalDate> plannedDates = new ArrayList<>();

        if (schedule.equalsIgnoreCase("DAILY")) {
            // Every day in range
            LocalDate current = fromDate;
            while (!current.isAfter(toDate)) {
                plannedDates.add(current);
                current = current.plusDays(1);
            }
        } else {
            // Parse specific days (e.g., "MONDAY,WEDNESDAY,FRIDAY")
            String[] scheduledDays = schedule.split(",");
            List<DayOfWeek> daysList = new ArrayList<>();

            for (String day : scheduledDays) {
                try {
                    daysList.add(DayOfWeek.valueOf(day.trim().toUpperCase()));
                } catch (IllegalArgumentException ignored) {}
            }

            // Iterate through date range and add matching days
            LocalDate current = fromDate;
            while (!current.isAfter(toDate)) {
                if (daysList.contains(current.getDayOfWeek())) {
                    plannedDates.add(current);
                }
                current = current.plusDays(1);
            }
        }

        return plannedDates;
    }

    /**
     * Fetch actual controller usage logs from Firestore
     */
    private static void fetchControllerLogs(FirebaseFirestore db,
                                            String childId,
                                            LocalDate fromDate,
                                            LocalDate toDate,
                                            List<LocalDate> plannedDates,
                                            AdherenceCallback callback) {

        long fromMillis = fromDate.atStartOfDay(ZoneId.systemDefault()).toInstant().toEpochMilli();
        long toMillis = toDate.atStartOfDay(ZoneId.systemDefault()).plusDays(1).toInstant().toEpochMilli();

        db.collection("controllerLogs")
                .document(childId)
                .collection("entries")
                .whereGreaterThanOrEqualTo("timestamp", fromMillis)
                .whereLessThan("timestamp", toMillis)
                .get()
                .addOnSuccessListener(querySnapshot -> {
                    // Build set of dates when controller was actually taken
                    Map<LocalDate, Boolean> completedDates = new HashMap<>();

                    for (DocumentSnapshot doc : querySnapshot.getDocuments()) {
                        Long timestamp = doc.getLong("timestamp");
                        if (timestamp != null) {
                            LocalDate logDate = Instant.ofEpochMilli(timestamp)
                                    .atZone(ZoneId.systemDefault())
                                    .toLocalDate();
                            completedDates.put(logDate, true);
                        }
                    }

                    // Calculate adherence
                    AdherenceResult result = new AdherenceResult();
                    result.plannedDays = plannedDates.size();
                    result.completedDays = 0;

                    for (LocalDate plannedDate : plannedDates) {
                        if (completedDates.containsKey(plannedDate)) {
                            result.completedDays++;
                        } else {
                            result.missedDays.add(plannedDate);
                        }
                    }

                    if (result.plannedDays > 0) {
                        result.adherencePercentage =
                                (result.completedDays * 100.0) / result.plannedDays;
                    } else {
                        result.adherencePercentage = 0.0;
                    }

                    callback.onCalculated(result);
                })
                .addOnFailureListener(callback::onError);
    }
}