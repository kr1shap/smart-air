package com.example.smart_air.fragments;

import android.graphics.Color;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.ViewFlipper;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.example.smart_air.R;
import com.example.smart_air.SettingsDialogFragment;

import com.example.smart_air.ReportGenerationHelper;

import com.github.mikephil.charting.charts.BarChart;
import com.github.mikephil.charting.charts.LineChart;
import com.github.mikephil.charting.components.XAxis;
import com.github.mikephil.charting.components.YAxis;
import com.github.mikephil.charting.data.BarData;
import com.github.mikephil.charting.data.BarDataSet;
import com.github.mikephil.charting.data.BarEntry;
import com.github.mikephil.charting.data.Entry;
import com.github.mikephil.charting.data.LineData;
import com.github.mikephil.charting.data.LineDataSet;
import com.github.mikephil.charting.formatter.IndexAxisValueFormatter;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;

import java.io.File;
import java.time.DayOfWeek;
import java.time.Instant;
import java.time.LocalDate;
import java.time.ZoneId;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;


public class DashboardFragment extends Fragment {

    private float x1, x2;
    private final int MIN_DISTANCE = 150;
    private View zoneBar;

    private String zoneColour = "none";
    private View barContainer;
    private LineChart zoneChart;
    private BarChart rescueChart;
    private FirebaseFirestore db = FirebaseFirestore.getInstance();
    private static final String CHILD_ID = FirebaseAuth.getInstance().getUid();

    private boolean showing30DayTrend = false;
    private TextView tvTrendToggle;

    // view creation

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_dashboard, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        zoneBar = view.findViewById(R.id.zoneBar);
        rescueChart = view.findViewById(R.id.rescueChart);
        zoneChart = view.findViewById(R.id.zoneChart);

        barContainer = view.findViewById(R.id.barContainer);
        barContainer.post(() -> updateZoneBar());
        loadTodayZone();
        super.onViewCreated(view, savedInstanceState);

        // Load user name and inventory data
        loadUserName();
        loadInventoryData();

        // Provider Report Button
        Button btnReport = view.findViewById(R.id.btnProviderReport);
        btnReport.setOnClickListener(v -> showProviderReportFragment());

        // Manage Children Button
        Button btnManageChildren = view.findViewById(R.id.btnManageChildren);
        if (btnManageChildren != null) {
            btnManageChildren.setOnClickListener(v -> {
                SettingsDialogFragment dialog = new SettingsDialogFragment();
                dialog.show(getParentFragmentManager(), "settings_dialog");
            });
        }

        FirebaseAuth auth = FirebaseAuth.getInstance();
        if (auth.getCurrentUser() == null) {
            Toast.makeText(getContext(), "Not logged in!", Toast.LENGTH_SHORT).show();
            // rediret to login
        } else {
            String userId = auth.getUid();
            System.out.println("Current User ID: " + userId);
        }

        db = FirebaseFirestore.getInstance();

        loadZoneHistory();
        loadWeeklyRescues();

        final ViewFlipper flipper = view.findViewById(R.id.trendsCarousel);
        if (flipper == null) {
            return;
        }
        flipper.post(() -> {
            flipper.setOnTouchListener((v, event) -> {
                v.getParent().requestDisallowInterceptTouchEvent(true);

                switch (event.getAction()) {
                    case MotionEvent.ACTION_DOWN:
                        x1 = event.getX();
                        return true;

                    case MotionEvent.ACTION_UP:
                        v.performClick();
                        x2 = event.getX();
                        float deltaX = x2 - x1;

                        if (Math.abs(deltaX) > MIN_DISTANCE) {
                            if (deltaX > 0) {
                                flipper.showPrevious();
                            } else {
                                flipper.showNext();
                            }

                            updateDots(flipper.getDisplayedChild(), view);
                        }
                        return true;
                }
                return false;
            });

            updateDots(0, view);

        });

    }


    // zone widget
    private void loadTodayZone() {
        String childId = FirebaseAuth.getInstance().getUid();

        FirebaseFirestore db = FirebaseFirestore.getInstance();

        db.collection("dailycheckin")
                .document(childId)
                .get()
                .addOnSuccessListener(doc -> {
                    if (doc.exists()) {
                        zoneColour = doc.getString("zoneColour");
                        if (zoneColour == null) zoneColour = "none";
                    } else {
                        zoneColour = "none";
                    }

                    updateZoneBar();
                })
                .addOnFailureListener(e -> {
                    zoneColour = "none";
                    updateZoneBar();
                });
    }

    private void updateZoneBar() {
        if (barContainer == null || zoneBar == null) return;

        int maxWidth = barContainer.getWidth();
        int newWidth;

        if ("green".equalsIgnoreCase(zoneColour)) {
            newWidth = (int) (0.33f * maxWidth);
            zoneBar.setBackgroundColor(Color.parseColor("#31ad36"));
        }
        else if ("yellow".equalsIgnoreCase(zoneColour)) {
            newWidth = (int) (0.66f * maxWidth);
            zoneBar.setBackgroundColor(Color.parseColor("#ffcc12"));
        }
        else if ("red".equalsIgnoreCase(zoneColour)) {
            newWidth = (int) (1.00f * maxWidth);
            zoneBar.setBackgroundColor(Color.parseColor("#b50000"));
        }
        else {
            newWidth = 0;
            zoneBar.setBackgroundColor(Color.GRAY);
        }

        ViewGroup.LayoutParams params = zoneBar.getLayoutParams();
        params.width = newWidth;
        zoneBar.setLayoutParams(params);
    }


    // weekly rescue and last rescue widgets
    private void loadWeeklyRescues() {

        String childId = FirebaseAuth.getInstance().getUid();

        db.collection("IncidentLog")
                .document(childId)
                .collection("TriageSession")
                .get()
                .addOnSuccessListener(sessionSnap -> {

                    ArrayList<Long> timestamps = new ArrayList<>();

                    if (sessionSnap.isEmpty()) {

                        updateWeeklyRescuesUI(0, "No rescues yet");
                        return;
                    }

                    final int totalSessions = sessionSnap.size();
                    final int[] loadedSessions = {0};

                    for (DocumentSnapshot sessionDoc : sessionSnap) {

                        db.collection("IncidentLog")
                                .document(childId)
                                .collection("TriageSession")
                                .document(sessionDoc.getId())
                                .collection("rescueAttempts")
                                .get()
                                .addOnSuccessListener(rescueSnap -> {

                                    for (DocumentSnapshot rescueDoc : rescueSnap) {
                                        Long ts = rescueDoc.getLong("timestamp");
                                        if (ts != null) timestamps.add(ts);
                                    }

                                    loadedSessions[0]++;

                                    if (loadedSessions[0] == totalSessions) {
                                        processRescues(timestamps);
                                    }

                                });
                    }

                });
    }

    private void processRescues(ArrayList<Long> timestamps) {

        int[] counts = countRescuesThisWeek(timestamps);
        int weeklyTotal = 0;
        for (int c : counts) weeklyTotal += c;

        String lastRescueDate = "No rescues yet";

        if (!timestamps.isEmpty()) {
            long lastTs = Collections.max(timestamps);

            LocalDate date = Instant.ofEpochMilli(lastTs)
                    .atZone(ZoneId.systemDefault())
                    .toLocalDate();

            lastRescueDate = date.toString();
        }

        updateWeeklyRescuesUI(weeklyTotal, lastRescueDate);

        // Only draw charts if fragment is still attached
        if (isAdded() && getView() != null) {
            drawWeeklyRescueChart(counts);
        }
    }

    private void updateWeeklyRescuesUI(int weeklyTotal, String lastRescueDate) {
        // Add null check to prevent crash when fragment is no longer attached
        if (getView() == null) return;

        TextView txtWeekly = getView().findViewById(R.id.tvWeeklyRescues);
        TextView txtLastRescue = getView().findViewById(R.id.tvLastRescue);

        if (txtWeekly != null) {
            txtWeekly.setText("Rescues this week: " + weeklyTotal);
        }
        if (txtLastRescue != null) {
            txtLastRescue.setText("Last rescue: " + lastRescueDate);
        }
    }


    // trends widget
    private void updateDots(int index, View view) {

        View dot1 = view.findViewById(R.id.dot1);
        View dot2 = view.findViewById(R.id.dot2);
        View dot3 = view.findViewById(R.id.dot3);

        dot1.setBackgroundResource(index == 0 ? R.drawable.dot_active : R.drawable.dot_inactive);
        dot2.setBackgroundResource(index == 1 ? R.drawable.dot_active : R.drawable.dot_inactive);
        dot3.setBackgroundResource(index == 2 ? R.drawable.dot_active : R.drawable.dot_inactive);
    }

    private void loadUserRole() {
        String uid = FirebaseAuth.getInstance().getUid();
        if (uid == null) return;

        FirebaseFirestore db = FirebaseFirestore.getInstance();

        db.collection("users")
                .document(uid)
                .get()
                .addOnSuccessListener(doc -> {
                    if (!doc.exists()) return;

                    String role = doc.getString("role");
                    if (role != null) {
                        applyRoleUI(role.toLowerCase());
                    }
                });
    }

    private void applyRoleUI(String role) {

        View todaysZoneWidget = getView().findViewById(R.id.zoneSection);
        View sevenDayChart = getView().findViewById(R.id.trendSection);
        View providerReportButton = getView().findViewById(R.id.btnProviderReport);
        View manageChildrenButton = getView().findViewById(R.id.btnManageChildren);

        switch (role) {

            case "parent":
                todaysZoneWidget.setVisibility(View.VISIBLE);
                sevenDayChart.setVisibility(View.VISIBLE);
                providerReportButton.setVisibility(View.VISIBLE);
                manageChildrenButton.setVisibility(View.VISIBLE);
                break;

            case "child":
                todaysZoneWidget.setVisibility(View.VISIBLE);
                sevenDayChart.setVisibility(View.VISIBLE);
                providerReportButton.setVisibility(View.GONE);
                manageChildrenButton.setVisibility(View.GONE);
                break;

            case "provider":
                todaysZoneWidget.setVisibility(View.GONE);
                sevenDayChart.setVisibility(View.VISIBLE);
                providerReportButton.setVisibility(View.VISIBLE);
                manageChildrenButton.setVisibility(View.GONE);
                break;

            default:
                todaysZoneWidget.setVisibility(View.GONE);
                sevenDayChart.setVisibility(View.GONE);
                providerReportButton.setVisibility(View.GONE);
                manageChildrenButton.setVisibility(View.GONE);
        }
    }

    private void loadZoneHistory() {

        LocalDate today = LocalDate.now();
        Entry[] entryArray = new Entry[7];

        String childId = FirebaseAuth.getInstance().getUid();

        for (int i = 0; i < 7; i++) {

            LocalDate day = today.minusDays(6 - i);
            String dateKey = day.toString();
            int index = i;

            db.collection("dailycheckin")
                    .document(childId)
                    .collection("entries")
                    .document(dateKey)
                    .get()
                    .addOnSuccessListener(doc -> {

                        if (doc.exists()) {

                            String zone = doc.getString("zoneColour");

                            if (zone == null) {
                                entryArray[index] = new Entry(index, 0);
                            } else {
                                switch (zone.toLowerCase()) {
                                    case "green":
                                        entryArray[index] = new Entry(index, 1);
                                        break;
                                    case "yellow":
                                        entryArray[index] = new Entry(index, 2);
                                        break;
                                    case "red":
                                        entryArray[index] = new Entry(index, 3);
                                        break;
                                    default:
                                        entryArray[index] = new Entry(index, 0);
                                }
                            }

                        } else {
                            entryArray[index] = new Entry(index, 0);
                        }

                        checkIfComplete(entryArray);
                    });
        }
    }

    private void checkIfComplete(Entry[] entryArray) {
        for (Entry e : entryArray) {
            if (e == null) return;
        }

        // Only draw chart if fragment is still attached
        if (isAdded() && getView() != null) {
            drawZoneHistoryChart(new ArrayList<>(Arrays.asList(entryArray)));
        }
    }

    private void drawZoneHistoryChart(ArrayList<Entry> entries) {

        zoneChart.setTouchEnabled(false);
        zoneChart.setPinchZoom(false);
        zoneChart.setDoubleTapToZoomEnabled(false);
        zoneChart.setDragEnabled(false);
        zoneChart.setScaleEnabled(false);
        zoneChart.setHighlightPerTapEnabled(false);
        zoneChart.setHighlightPerDragEnabled(false);

        LineDataSet dataSet = new LineDataSet(entries, "Zone (Past 7 Days)");
        dataSet.setColor(Color.BLACK);
        dataSet.setCircleColor(Color.BLACK);
        dataSet.setLineWidth(2f);
        dataSet.setCircleRadius(4f);
        dataSet.setDrawValues(false);

        YAxis left = zoneChart.getAxisLeft();
        left.setAxisMinimum(0f);
        left.setAxisMaximum(30f);
        left.setDrawGridLines(false);
        zoneChart.getAxisRight().setEnabled(false);

        String[] labels = {"S", "M", "T", "W", "T", "F", "S"};

        XAxis x = zoneChart.getXAxis();
        x.setValueFormatter(new IndexAxisValueFormatter(labels));
        x.setPosition(XAxis.XAxisPosition.BOTTOM);
        x.setGranularity(1f);
        x.setLabelCount(7, true);
        x.setDrawGridLines(false);

        x.setAxisMaximum(6.3f);
        x.setAvoidFirstLastClipping(false);

        x.setEnabled(true);
        x.setDrawLabels(true);

        zoneChart.setExtraBottomOffset(20f);

        zoneChart.getDescription().setEnabled(false);
        zoneChart.getLegend().setEnabled(false);

        zoneChart.setData(new LineData(dataSet));
        zoneChart.invalidate();
    }


    private LocalDate getStartOfWeek() {
        LocalDate today = LocalDate.now();
        return today.with(DayOfWeek.SUNDAY);
    }

    private LocalDate getEndOfWeek() {
        LocalDate today = LocalDate.now();
        return today.with(DayOfWeek.SATURDAY);
    }

    private int[] countRescuesThisWeek(ArrayList<Long> timestamps) {
        int[] counts = new int[7];

        LocalDate start = getStartOfWeek();
        LocalDate end = getEndOfWeek();

        for (long ts : timestamps) {
            LocalDate date = Instant.ofEpochMilli(ts)
                    .atZone(ZoneId.systemDefault())
                    .toLocalDate();

            if (!date.isBefore(start) && !date.isAfter(end)) {
                int dayIndex = date.getDayOfWeek().getValue() % 7;

                counts[dayIndex]++;
            }
        }

        return counts;
    }

    private void drawWeeklyRescueChart(int[] counts) {
        ArrayList<BarEntry> entries = buildEntriesForWeek(counts);

        BarDataSet dataSet = new BarDataSet(entries, "Rescue Uses");
        dataSet.setColor(Color.parseColor("#3F51B5"));
        dataSet.setDrawValues(false);

        BarData barData = new BarData(dataSet);
        barData.setBarWidth(0.5f);

        String[] days = {"Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"};

        XAxis xAxis = rescueChart.getXAxis();
        xAxis.setValueFormatter(new IndexAxisValueFormatter(days));
        xAxis.setPosition(XAxis.XAxisPosition.BOTTOM);
        xAxis.setGranularity(1f);
        xAxis.setLabelCount(7);
        xAxis.setDrawGridLines(false);

        rescueChart.getAxisRight().setEnabled(false);
        rescueChart.getAxisLeft().setAxisMinimum(0f);

        rescueChart.setData(barData);
        rescueChart.setFitBars(true);
        rescueChart.invalidate();
    }

    private ArrayList<BarEntry> buildEntriesForWeek(int[] counts) {
        ArrayList<BarEntry> entries = new ArrayList<>();
        for (int i = 0; i < 7; i++) {
            entries.add(new BarEntry(i, counts[i]));
        }
        return entries;
    }

    /**
     * Generates a provider report using the ReportGenerationHelper
     * @param months Number of months to include in the report
     */
    public void generateProviderReport(int months) {
        String childId = FirebaseAuth.getInstance().getUid();

        if (childId == null) {
            Toast.makeText(getContext(), "Error: User not authenticated", Toast.LENGTH_SHORT).show();
            return;
        }

        ReportGenerationHelper helper = new ReportGenerationHelper(requireContext(), childId);

        helper.generateReport(months, new ReportGenerationHelper.ReportCallback() {
            @Override
            public void onSuccess(File pdfFile) {
                if (getContext() != null) {
                    Toast.makeText(getContext(),
                            "PDF saved: " + pdfFile.getAbsolutePath(),
                            Toast.LENGTH_LONG).show();

                    helper.openPdf(pdfFile);
                }
            }

            @Override
            public void onError(String errorMessage) {
                if (getContext() != null) {
                    Toast.makeText(getContext(),
                            "Error: " + errorMessage,
                            Toast.LENGTH_SHORT).show();
                }
            }
        });
    }

    /**
     * Shows the provider report fragment
     */
    private void showProviderReportFragment() {
        String childId = FirebaseAuth.getInstance().getUid();

        if (childId == null) {
            Toast.makeText(getContext(), "Error: User not authenticated", Toast.LENGTH_SHORT).show();
            return;
        }

        ProviderReportFragment fragment = ProviderReportFragment.newInstance(childId, 4);

        requireActivity().getSupportFragmentManager()
                .beginTransaction()
                .replace(R.id.fragment_container, fragment)
                .addToBackStack(null)
                .commit();
    }

    /**
     * Load and display the user's name in the dashboard title
     */
    private void loadUserName() {
        String uid = FirebaseAuth.getInstance().getUid();
        if (uid == null) return;

        db.collection("users")
                .document(uid)
                .get()
                .addOnSuccessListener(doc -> {
                    // Check if fragment is still attached
                    if (!isAdded() || getView() == null) return;

                    if (doc.exists()) {
                        String name = doc.getString("name");

                        if (name != null && !name.isEmpty()) {
                            updateDashboardTitle(name);
                        } else {
                            TextView titleView = getView().findViewById(R.id.tvDashboardTitle);
                            if (titleView != null) {
                                titleView.setText("Dashboard");
                            }
                        }
                    }
                })
                .addOnFailureListener(e -> {
                    if (!isAdded() || getView() == null) return;

                    TextView titleView = getView().findViewById(R.id.tvDashboardTitle);
                    if (titleView != null) {
                        titleView.setText("Dashboard");
                    }
                });
    }

    /**
     * Updates the dashboard title with proper possessive form
     */
    private void updateDashboardTitle(String name) {
        if (getView() == null) return;

        TextView titleView = getView().findViewById(R.id.tvDashboardTitle);
        if (titleView != null) {
            String title;
            if (name.endsWith("s")) {
                title = name + "' Dashboard";
            } else {
                title = name + "'s Dashboard";
            }
            titleView.setText(title);
        }
    }

    /**
     * Load inventory data from Firestore
     */
    private void loadInventoryData() {
        String uid = FirebaseAuth.getInstance().getUid();
        if (uid == null) return;

        db.collection("inventory")
                .document(uid)
                .get()
                .addOnSuccessListener(doc -> {
                    // Check if fragment is still attached
                    if (!isAdded() || getView() == null) return;

                    TextView tvRescue = getView().findViewById(R.id.tvInventoryRescue);
                    TextView tvController = getView().findViewById(R.id.tvInventoryController);

                    if (doc.exists()) {
                        Long rescueCount = doc.getLong("rescueInhalerCount");
                        String rescueText = rescueCount != null ?
                                rescueCount + " inhalers" : "No data";

                        Long controllerCount = doc.getLong("controllerInhalerCount");
                        String controllerText = controllerCount != null ?
                                controllerCount + " inhalers" : "No data";

                        if (tvRescue != null) tvRescue.setText(rescueText);
                        if (tvController != null) tvController.setText(controllerText);
                    } else {
                        if (tvRescue != null) tvRescue.setText("No data");
                        if (tvController != null) tvController.setText("No data");
                    }
                })
                .addOnFailureListener(e -> {
                    if (!isAdded() || getView() == null) return;

                    TextView tvRescue = getView().findViewById(R.id.tvInventoryRescue);
                    TextView tvController = getView().findViewById(R.id.tvInventoryController);

                    if (tvRescue != null) tvRescue.setText("No data");
                    if (tvController != null) tvController.setText("No data");
                });
    }
}