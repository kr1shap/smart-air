package com.example.smart_air;

import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Typeface;
import android.graphics.pdf.PdfDocument;
import android.net.Uri;
import android.widget.Toast;

import androidx.core.content.FileProvider;
import androidx.core.content.res.ResourcesCompat;

import com.github.mikephil.charting.charts.LineChart;
import com.github.mikephil.charting.charts.PieChart;
import com.github.mikephil.charting.components.XAxis;
import com.github.mikephil.charting.data.Entry;
import com.github.mikephil.charting.data.LineData;
import com.github.mikephil.charting.data.LineDataSet;
import com.github.mikephil.charting.data.PieData;
import com.github.mikephil.charting.data.PieDataSet;
import com.github.mikephil.charting.data.PieEntry;
import com.google.android.gms.tasks.Task;
import com.google.android.gms.tasks.Tasks;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QuerySnapshot;

import java.io.File;
import java.io.FileOutputStream;
import java.time.Instant;
import java.time.LocalDate;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Helper class to generate provider reports for a child's asthma data
 */
public class ReportGenerationHelper {

    private final Context context;
    private final FirebaseFirestore db;
    private final String childId;
    private Typeface dmSansFont;

    public ReportGenerationHelper(Context context, String childId) {
        this.context = context;
        this.childId = childId;
        this.db = FirebaseFirestore.getInstance();

        // Load dm_sans font
        try {
            dmSansFont = ResourcesCompat.getFont(context, R.font.dm_sans_regular);
        } catch (Exception e) {
            dmSansFont = Typeface.DEFAULT;
        }
    }

    /**
     * Generates a provider report for the specified number of months
     * @param months Number of months to include in the report
     * @param callback Callback to handle success/failure
     */
    public void generateReport(int months, ReportCallback callback) {
        if (months < 1 || months > 12) {
            callback.onError("Invalid month range. Must be between 1 and 12.");
            return;
        }

        LocalDate today = LocalDate.now();
        LocalDate fromDate = today.minusMonths(months);
        long fromMillis = fromDate.atStartOfDay(ZoneId.systemDefault())
                .toInstant()
                .toEpochMilli();

        // First, load child permissions
        db.collection("users")
                .document(childId)
                .get()
                .addOnSuccessListener(childDoc -> {
                    Map<String, Object> permissions = new HashMap<>();
                    if (childDoc.exists() && childDoc.contains("reportPermissions")) {
                        Object perms = childDoc.get("reportPermissions");
                        if (perms instanceof Map) {
                            permissions = (Map<String, Object>) perms;
                        }
                    }

                    // Continue with data loading
                    loadTriageData(months, fromDate, fromMillis, permissions, callback);
                })
                .addOnFailureListener(e -> {
                    // Continue without permissions if loading fails
                    loadTriageData(months, fromDate, fromMillis, new HashMap<>(), callback);
                });
    }

    private void loadTriageData(int months, LocalDate fromDate, long fromMillis,
                                Map<String, Object> permissions, ReportCallback callback) {
        // Fetch triage data
        Task<QuerySnapshot> triageTask = db.collection("IncidentLog")
                .document(childId)
                .collection("TriageSession")
                .whereGreaterThanOrEqualTo("timestamp", fromMillis)
                .get();

        triageTask.addOnSuccessListener(triageSnap -> {
            processTriageData(triageSnap, months, fromDate, permissions, callback);
        }).addOnFailureListener(e -> {
            callback.onError("Error loading triage sessions: " + e.getMessage());
        });
    }

    private void processTriageData(QuerySnapshot triageSnap, int months,
                                   LocalDate fromDate, Map<String, Object> permissions,
                                   ReportCallback callback) {
        List<DocumentSnapshot> triageDocs = triageSnap.getDocuments();

        if (triageDocs.isEmpty()) {
            // No triage data, proceed with just zone data
            loadZoneData(months, 0, 0L, new ArrayList<>(), fromDate, permissions, callback);
            return;
        }

        List<Task<QuerySnapshot>> rescueTasks = new ArrayList<>();
        for (DocumentSnapshot sessionDoc : triageDocs) {
            Task<QuerySnapshot> t = sessionDoc.getReference()
                    .collection("rescueAttempts")
                    .get();
            rescueTasks.add(t);
        }

        Tasks.whenAllSuccess(rescueTasks)
                .addOnSuccessListener(results -> {
                    int totalRescues = 0;
                    long latestRescueTs = 0L;

                    for (Object obj : results) {
                        QuerySnapshot snap = (QuerySnapshot) obj;
                        for (DocumentSnapshot rescueDoc : snap.getDocuments()) {
                            Long ts = rescueDoc.getLong("timestamp");
                            if (ts != null) {
                                totalRescues++;
                                if (ts > latestRescueTs) {
                                    latestRescueTs = ts;
                                }
                            }
                        }
                    }

                    loadZoneData(months, totalRescues, latestRescueTs,
                            triageDocs, fromDate, permissions, callback);
                })
                .addOnFailureListener(e -> {
                    callback.onError("Error loading rescue attempts: " + e.getMessage());
                });
    }

    private void loadZoneData(int months, int totalRescues, long latestRescueTs,
                              List<DocumentSnapshot> triageDocs, LocalDate fromDate,
                              Map<String, Object> permissions, ReportCallback callback) {
        db.collection("dailycheckin")
                .document(childId)
                .collection("entries")
                .get()
                .addOnSuccessListener(entriesSnap -> {
                    ZoneCounts counts = calculateZoneCounts(entriesSnap, fromDate);

                    File pdfFile = buildPdf(months, totalRescues, latestRescueTs,
                            counts, triageDocs, permissions);

                    if (pdfFile != null) {
                        callback.onSuccess(pdfFile);
                    } else {
                        callback.onError("Failed to create PDF file");
                    }
                })
                .addOnFailureListener(e -> {
                    callback.onError("Error loading daily check-ins: " + e.getMessage());
                });
    }

    private ZoneCounts calculateZoneCounts(QuerySnapshot entriesSnap, LocalDate fromDate) {
        int greenCount = 0;
        int yellowCount = 0;
        int redCount = 0;

        for (DocumentSnapshot doc : entriesSnap.getDocuments()) {
            String docId = doc.getId();
            try {
                LocalDate entryDate = LocalDate.parse(docId);
                if (entryDate.isBefore(fromDate)) {
                    continue;
                }
            } catch (Exception e) {
                continue;
            }

            String zone = doc.getString("zoneColour");
            if (zone == null) continue;

            switch (zone.toLowerCase()) {
                case "green":
                    greenCount++;
                    break;
                case "yellow":
                    yellowCount++;
                    break;
                case "red":
                    redCount++;
                    break;
            }
        }

        return new ZoneCounts(greenCount, yellowCount, redCount);
    }

    private File buildPdf(int months, int totalRescues, long latestRescueTs,
                          ZoneCounts zoneCounts, List<DocumentSnapshot> triageDocs,
                          Map<String, Object> permissions) {
        PdfDocument pdf = new PdfDocument();
        Paint paint = new Paint();

        try {
            PdfDocument.PageInfo pageInfo =
                    new PdfDocument.PageInfo.Builder(595, 842, 1).create();
            PdfDocument.Page page = pdf.startPage(pageInfo);
            Canvas canvas = page.getCanvas();

            int centerX = pageInfo.getPageWidth() / 2;
            int y = 80;

            paint.setTextAlign(Paint.Align.CENTER);
            paint.setTextSize(28);
            paint.setTypeface(Typeface.create(dmSansFont, Typeface.BOLD));
            canvas.drawText("Provider Report", centerX, y, paint);

            y += 40;
            paint.setTextSize(18);
            paint.setTypeface(dmSansFont);
            canvas.drawText("Past " + months + " months", centerX, y, paint);

            paint.setTextAlign(Paint.Align.LEFT);
            y += 40;

            // rescue frequency section
            y = addRescueSection(canvas, paint, y, totalRescues, latestRescueTs);

            // add line chart for rescue frequency over time
            Bitmap rescueChart = createRescueTimelineChart();
            if (rescueChart != null) {
                canvas.drawBitmap(rescueChart, 40, y, null);
                y += rescueChart.getHeight() + 20;
                rescueChart.recycle();
            }

            // Zone distribution section with pie chart
            y =addZoneSection(canvas, paint, y, zoneCounts);

            Bitmap pieChart = createZonePieChart(zoneCounts);
            if (pieChart != null) {
                canvas.drawBitmap(pieChart, 40, y, null);
                y += pieChart.getHeight() + 20;
                pieChart.recycle();
            }

            // check permission for notable triage incidents
            boolean showTriageIncidents = getPermission(permissions, "notableTriageIncidents", true);
            if (showTriageIncidents) {
                y = addTriageSection(canvas, paint, y, triageDocs);
            }

            // placeholder sections
            y = addPlaceholderSection(canvas, paint, y, "Controller adherence",
                    "Planned vs actual controller use: (to be added once schedule is defined)");

            addPlaceholderSection(canvas, paint, y, "Symptom burden",
                    "Problem day counts: (to be added once symptom fields are finalized)");

            pdf.finishPage(page);

            File path = new File(context.getExternalFilesDir(null),
                    "provider_report_" + System.currentTimeMillis() + ".pdf");

            try (FileOutputStream fos = new FileOutputStream(path)) {
                pdf.writeTo(fos);
                return path;
            }
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        } finally {
            pdf.close();
        }
    }

    private boolean getPermission(Map<String, Object> permissions, String key, boolean defaultValue) {
        if (permissions.containsKey(key)) {
            Object value = permissions.get(key);
            if (value instanceof Boolean) {
                return (Boolean) value;
            }
        }
        return defaultValue;
    }

    private Bitmap createRescueTimelineChart() {
        try {
            LineChart chart = new LineChart(context);
            chart.setLayoutParams(new LineChart.LayoutParams(500, 250));
            chart.layout(0, 0, 500, 250);

            // sample data - replace with actual rescue timeline data
            ArrayList<Entry> entries = new ArrayList<>();
            for (int i = 0; i < 7; i++) {
                entries.add(new Entry(i, (float) (Math.random() * 5)));
            }

            LineDataSet dataSet = new LineDataSet(entries, "Rescue Uses Over Time");
            dataSet.setColor(Color.parseColor("#3F51B5"));
            dataSet.setCircleColor(Color.parseColor("#3F51B5"));
            dataSet.setLineWidth(2f);
            dataSet.setCircleRadius(4f);
            dataSet.setDrawValues(false);

            LineData lineData = new LineData(dataSet);
            chart.setData(lineData);

            XAxis xAxis = chart.getXAxis();
            xAxis.setPosition(XAxis.XAxisPosition.BOTTOM);
            xAxis.setDrawGridLines(false);

            chart.getAxisRight().setEnabled(false);
            chart.getDescription().setEnabled(false);
            chart.getLegend().setEnabled(false);

            chart.invalidate();

            Bitmap bitmap = Bitmap.createBitmap(500, 250, Bitmap.Config.ARGB_8888);
            Canvas canvas = new Canvas(bitmap);
            chart.draw(canvas);

            return bitmap;
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }

    private Bitmap createZonePieChart(ZoneCounts counts) {
        try {
            PieChart chart = new PieChart(context);
            chart.setLayoutParams(new PieChart.LayoutParams(400, 300));
            chart.layout(0, 0, 400, 300);

            ArrayList<PieEntry> entries = new ArrayList<>();
            if (counts.greenCount > 0) entries.add(new PieEntry(counts.greenCount, "Green"));
            if (counts.yellowCount > 0) entries.add(new PieEntry(counts.yellowCount, "Yellow"));
            if (counts.redCount > 0) entries.add(new PieEntry(counts.redCount, "Red"));

            PieDataSet dataSet = new PieDataSet(entries, "Zone Distribution");

            ArrayList<Integer> colors = new ArrayList<>();
            if (counts.greenCount > 0) colors.add(Color.parseColor("#31ad36"));
            if (counts.yellowCount > 0) colors.add(Color.parseColor("#ffcc12"));
            if (counts.redCount > 0) colors.add(Color.parseColor("#b50000"));

            dataSet.setColors(colors);
            dataSet.setValueTextSize(12f);
            dataSet.setValueTextColor(Color.WHITE);

            PieData pieData = new PieData(dataSet);
            chart.setData(pieData);
            chart.getDescription().setEnabled(false);
            chart.setDrawHoleEnabled(true);
            chart.setHoleRadius(40f);
            chart.setTransparentCircleRadius(45f);

            chart.invalidate();

            Bitmap bitmap = Bitmap.createBitmap(400, 300, Bitmap.Config.ARGB_8888);
            Canvas canvas = new Canvas(bitmap);
            chart.draw(canvas);

            return bitmap;
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }

    private int addRescueSection(Canvas canvas, Paint paint, int y,
                                 int totalRescues, long latestRescueTs) {
        paint.setTextSize(16);
        paint.setTypeface(Typeface.create(dmSansFont, Typeface.BOLD));
        canvas.drawText("Rescue frequency", 40, y, paint);

        paint.setTypeface(dmSansFont);
        y += 25;
        canvas.drawText("Total rescues in period: " + totalRescues, 60, y, paint);

        y += 25;
        String lastRescueText;
        if (latestRescueTs == 0L) {
            lastRescueText = "Last rescue: none recorded in this period";
        } else {
            LocalDate lastDate = Instant.ofEpochMilli(latestRescueTs)
                    .atZone(ZoneId.systemDefault())
                    .toLocalDate();
            String formatted = lastDate.format(DateTimeFormatter.ofPattern("MMM dd, yyyy"));
            lastRescueText = "Last rescue: " + formatted;
        }
        canvas.drawText(lastRescueText, 60, y, paint);

        return y + 40;
    }

    private int addZoneSection(Canvas canvas, Paint paint, int y, ZoneCounts counts) {
        paint.setTypeface(Typeface.create(dmSansFont, Typeface.BOLD));
        canvas.drawText("Zone distribution over time", 40, y, paint);

        paint.setTypeface(dmSansFont);
        y += 25;
        canvas.drawText("Green days:  " + counts.greenCount, 60, y, paint);
        y += 20;
        canvas.drawText("Yellow days: " + counts.yellowCount, 60, y, paint);
        y += 20;
        canvas.drawText("Red days:    " + counts.redCount, 60, y, paint);

        return y + 40;
    }

    private int addTriageSection(Canvas canvas, Paint paint, int y,
                                 List<DocumentSnapshot> triageDocs) {
        paint.setTypeface(Typeface.create(dmSansFont, Typeface.BOLD));
        canvas.drawText("Notable triage incidents", 40, y, paint);

        paint.setTypeface(dmSansFont);
        y += 25;

        if (triageDocs.isEmpty()) {
            canvas.drawText("No triage incidents recorded in this period.", 60, y, paint);
            return y + 40;
        }

        int maxIncidents = Math.min(3, triageDocs.size());
        for (int i = 0; i < maxIncidents; i++) {
            DocumentSnapshot triageDoc = triageDocs.get(i);
            Long ts = triageDoc.getLong("timestamp");
            String severity = triageDoc.getString("severity");
            String trigger = triageDoc.getString("trigger");

            String dateStr = "Unknown date";
            if (ts != null) {
                LocalDate d = Instant.ofEpochMilli(ts)
                        .atZone(ZoneId.systemDefault())
                        .toLocalDate();
                dateStr = d.format(DateTimeFormatter.ofPattern("MMM dd, yyyy"));
            }

            canvas.drawText("- " + dateStr, 60, y, paint);
            y += 18;

            if (severity != null && !severity.isEmpty()) {
                canvas.drawText("  Severity: " + severity, 80, y, paint);
                y += 18;
            }

            if (trigger != null && !trigger.isEmpty()) {
                canvas.drawText("  Trigger: " + trigger, 80, y, paint);
                y += 18;
            }

            y += 10;
        }

        return y + 40;
    }

    private int addPlaceholderSection(Canvas canvas, Paint paint, int y,
                                      String title, String content) {
        paint.setTypeface(Typeface.create(dmSansFont, Typeface.BOLD));
        canvas.drawText(title, 40, y, paint);

        paint.setTypeface(dmSansFont);
        y += 25;
        canvas.drawText(content, 60, y, paint);

        return y + 40;
    }

    public void openPdf(File file) {
        try {
            Uri uri = FileProvider.getUriForFile(
                    context,
                    context.getPackageName() + ".provider",
                    file
            );

            Intent intent = new Intent(Intent.ACTION_VIEW);
            intent.setDataAndType(uri, "application/pdf");
            intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);

            context.startActivity(intent);
        } catch (Exception e) {
            Toast.makeText(context,
                    "No PDF viewer found. File saved at: " + file.getAbsolutePath(),
                    Toast.LENGTH_LONG).show();
        }
    }

    // Helper classes
    private static class ZoneCounts {
        final int greenCount;
        final int yellowCount;
        final int redCount;

        ZoneCounts(int green, int yellow, int red) {
            this.greenCount = green;
            this.yellowCount = yellow;
            this.redCount = red;
        }
    }

    public interface ReportCallback {
        void onSuccess(File pdfFile);
        void onError(String errorMessage);
    }
}