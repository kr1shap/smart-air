package com.example.smart_air.helpers;

import android.graphics.Color;

import com.github.mikephil.charting.charts.BarChart;
import com.github.mikephil.charting.charts.LineChart;
import com.github.mikephil.charting.charts.PieChart;
import com.github.mikephil.charting.components.XAxis;
import com.github.mikephil.charting.components.YAxis;
import com.github.mikephil.charting.data.BarData;
import com.github.mikephil.charting.data.BarDataSet;
import com.github.mikephil.charting.data.BarEntry;
import com.github.mikephil.charting.data.Entry;
import com.github.mikephil.charting.data.LineData;
import com.github.mikephil.charting.data.LineDataSet;
import com.github.mikephil.charting.data.PieData;
import com.github.mikephil.charting.data.PieDataSet;
import com.github.mikephil.charting.data.PieEntry;
import com.github.mikephil.charting.formatter.IndexAxisValueFormatter;

import java.util.ArrayList;
import java.util.List;

/**
 * ChartHelper - Reusable chart configuration utility
 * Provides standardized chart styling and setup for consistency across the app
 */
public class ChartHelper {

    // Zone colors matching your existing design
    public static final int COLOR_GREEN = Color.parseColor("#31ad36");
    public static final int COLOR_YELLOW = Color.parseColor("#ffcc12");
    public static final int COLOR_RED = Color.parseColor("#b50000");
    public static final int COLOR_PRIMARY = Color.parseColor("#3F51B5");

    /**
     * Configure a line chart with standard styling
     */
    public static void configureLineChart(LineChart chart, String[] xLabels, float maxY) {
        chart.setTouchEnabled(false);
        chart.setPinchZoom(false);
        chart.setDoubleTapToZoomEnabled(false);
        chart.setDragEnabled(false);
        chart.setScaleEnabled(false);
        chart.setHighlightPerTapEnabled(false);
        chart.setHighlightPerDragEnabled(false);
        chart.getDescription().setEnabled(false);
        chart.getLegend().setEnabled(false);

        // Y-axis
        YAxis leftAxis = chart.getAxisLeft();
        leftAxis.setAxisMinimum(0f);
        leftAxis.setAxisMaximum(maxY);
        leftAxis.setDrawGridLines(false);
        chart.getAxisRight().setEnabled(false);

        // X-axis
        XAxis xAxis = chart.getXAxis();
        xAxis.setValueFormatter(new IndexAxisValueFormatter(xLabels));
        xAxis.setPosition(XAxis.XAxisPosition.BOTTOM);
        xAxis.setGranularity(1f);
        xAxis.setLabelCount(xLabels.length, true);
        xAxis.setDrawGridLines(false);
        xAxis.setEnabled(true);
        xAxis.setDrawLabels(true);

        chart.setExtraBottomOffset(20f);
    }

    /**
     * Create a line dataset with standard styling
     */
    public static LineDataSet createLineDataSet(List<Entry> entries, String label, int color) {
        LineDataSet dataSet = new LineDataSet(entries, label);
        dataSet.setColor(color);
        dataSet.setCircleColor(color);
        dataSet.setLineWidth(2f);
        dataSet.setCircleRadius(4f);
        dataSet.setDrawValues(false);
        return dataSet;
    }

    /**
     * Configure a bar chart with standard styling
     */
    public static void configureBarChart(BarChart chart, String[] xLabels) {
        chart.setTouchEnabled(false);
        chart.setPinchZoom(false);
        chart.setDoubleTapToZoomEnabled(false);
        chart.setDragEnabled(false);
        chart.setScaleEnabled(false);
        chart.getDescription().setEnabled(false);
        chart.getLegend().setEnabled(false);

        // X-axis
        XAxis xAxis = chart.getXAxis();
        xAxis.setValueFormatter(new IndexAxisValueFormatter(xLabels));
        xAxis.setPosition(XAxis.XAxisPosition.BOTTOM);
        xAxis.setGranularity(1f);
        xAxis.setLabelCount(xLabels.length);
        xAxis.setDrawGridLines(false);

        // Y-axis
        chart.getAxisRight().setEnabled(false);
        chart.getAxisLeft().setAxisMinimum(0f);
        chart.getAxisLeft().setDrawGridLines(true);
    }

    /**
     * Create a bar dataset with standard styling
     */
    public static BarDataSet createBarDataSet(List<BarEntry> entries, String label, int color) {
        BarDataSet dataSet = new BarDataSet(entries, label);
        dataSet.setColor(color);
        dataSet.setDrawValues(false);
        return dataSet;
    }

    /**
     * Configure a pie chart with standard styling
     */
    public static void configurePieChart(PieChart chart) {
        chart.setUsePercentValues(true);
        chart.getDescription().setEnabled(false);
        chart.setDrawHoleEnabled(true);
        chart.setHoleColor(Color.WHITE);
        chart.setTransparentCircleRadius(61f);
        chart.setRotationEnabled(false);
        chart.setHighlightPerTapEnabled(false);
        chart.getLegend().setEnabled(true);
    }

    /**
     * Create zone distribution pie chart data
     */
    public static PieData createZonePieData(int greenCount, int yellowCount, int redCount) {
        ArrayList<PieEntry> entries = new ArrayList<>();

        if (greenCount > 0) entries.add(new PieEntry(greenCount, "Green"));
        if (yellowCount > 0) entries.add(new PieEntry(yellowCount, "Yellow"));
        if (redCount > 0) entries.add(new PieEntry(redCount, "Red"));

        PieDataSet dataSet = new PieDataSet(entries, "Zone Distribution");

        ArrayList<Integer> colors = new ArrayList<>();
        if (greenCount > 0) colors.add(COLOR_GREEN);
        if (yellowCount > 0) colors.add(COLOR_YELLOW);
        if (redCount > 0) colors.add(COLOR_RED);

        dataSet.setColors(colors);
        dataSet.setValueTextSize(12f);
        dataSet.setValueTextColor(Color.WHITE);

        return new PieData(dataSet);
    }
}