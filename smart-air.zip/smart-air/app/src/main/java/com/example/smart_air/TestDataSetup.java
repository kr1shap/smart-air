package com.example.smart_air;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.FirebaseFirestore;

import java.util.HashMap;
import java.util.Map;

/**
 * Helper class to set up test data in Firestore
 * Call this once from your MainActivity or a debug screen
 */
public class TestDataSetup {

    private final FirebaseFirestore db;
    private final String userId;

    public TestDataSetup() {
        this.db = FirebaseFirestore.getInstance();
        this.userId = FirebaseAuth.getInstance().getUid();
    }

    /**
     * Set up all test data for the current user
     */
    public void setupAllTestData() {
        if (userId == null) {
            System.err.println("User not authenticated");
            return;
        }

        setupUserName();
        setupInventoryData();
        setupReportPermissions();
        setupTodayZone();

        System.out.println("Test data setup complete!");
    }

    /**
     * Set up user name
     */
    private void setupUserName() {
        Map<String, Object> userData = new HashMap<>();
        userData.put("name", "John Smith"); // Change this to your name
        userData.put("role", "parent"); // or "child" or "provider"
        userData.put("email", "test@example.com");

        db.collection("users")
                .document(userId)
                .set(userData)
                .addOnSuccessListener(aVoid ->
                        System.out.println("✓ User name set"))
                .addOnFailureListener(e ->
                        System.err.println("✗ Failed to set user name: " + e.getMessage()));
    }

    /**
     * Set up inventory data
     */
    private void setupInventoryData() {
        Map<String, Object> inventoryData = new HashMap<>();
        inventoryData.put("rescueInhalerCount", 3);
        inventoryData.put("controllerInhalerCount", 2);

        db.collection("inventory")
                .document(userId)
                .set(inventoryData)
                .addOnSuccessListener(aVoid ->
                        System.out.println("✓ Inventory data set"))
                .addOnFailureListener(e ->
                        System.err.println("✗ Failed to set inventory: " + e.getMessage()));
    }

    /**
     * Set up report permissions
     */
    private void setupReportPermissions() {
        Map<String, Object> permissions = new HashMap<>();
        permissions.put("notableTriageIncidents", true);
        permissions.put("medicationHistory", true);
        permissions.put("peakFlowData", true);

        Map<String, Object> update = new HashMap<>();
        update.put("reportPermissions", permissions);

        db.collection("users")
                .document(userId)
                .update(update)
                .addOnSuccessListener(aVoid ->
                        System.out.println("✓ Report permissions set"))
                .addOnFailureListener(e ->
                        System.err.println("✗ Failed to set permissions: " + e.getMessage()));
    }

    /**
     * Set up today's zone
     */
    private void setupTodayZone() {
        Map<String, Object> zoneData = new HashMap<>();
        zoneData.put("zoneColour", "green"); // or "yellow" or "red"

        db.collection("dailycheckin")
                .document(userId)
                .set(zoneData)
                .addOnSuccessListener(aVoid ->
                        System.out.println("✓ Today's zone set"))
                .addOnFailureListener(e ->
                        System.err.println("✗ Failed to set zone: " + e.getMessage()));
    }
}