package com.example.smart_air.fragments;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.Spinner;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.example.smart_air.R;
import com.example.smart_air.ReportGenerationHelper;

import java.io.File;
import java.util.Arrays;
import java.util.List;

public class ProviderReportFragment extends Fragment {

    private static final String ARG_CHILD_ID = "child_id";
    private static final String ARG_DEFAULT_MONTHS = "default_months";

    private String childId;
    private int defaultMonths;

    private Spinner spinnerMonths;
    private Button btnGenerate;
    private Button btnCancel;

    public ProviderReportFragment() {
        // Required empty constructor
    }

    /**
     * Creates a new instance of ProviderReportFragment
     * @param childId The Firebase UID of the child for the report
     * @param defaultMonths The default number of months to select (3-6)
     */
    public static ProviderReportFragment newInstance(String childId, int defaultMonths) {
        ProviderReportFragment fragment = new ProviderReportFragment();
        Bundle args = new Bundle();
        args.putString(ARG_CHILD_ID, childId);
        args.putInt(ARG_DEFAULT_MONTHS, defaultMonths);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            childId = getArguments().getString(ARG_CHILD_ID);
            defaultMonths = getArguments().getInt(ARG_DEFAULT_MONTHS, 4);
        }
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater,
                             @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_provider_report, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        initializeViews(view);
        setupSpinner();
        setupButtons();
    }

    private void initializeViews(View view) {
        spinnerMonths = view.findViewById(R.id.spinnerMonths);
        btnGenerate = view.findViewById(R.id.btnGenerate);
        btnCancel = view.findViewById(R.id.btnCancel);
    }

    private void setupSpinner() {
        List<String> options = Arrays.asList(
                "Past 3 months",
                "Past 4 months",
                "Past 5 months",
                "Past 6 months"
        );

        ArrayAdapter<String> adapter = new ArrayAdapter<>(
                requireContext(),
                android.R.layout.simple_spinner_dropdown_item,
                options
        );
        spinnerMonths.setAdapter(adapter);

        // Set default selection based on defaultMonths
        int defaultPosition = Math.max(0, Math.min(defaultMonths - 3, options.size() - 1));
        spinnerMonths.setSelection(defaultPosition);
    }

    private void setupButtons() {
        btnCancel.setOnClickListener(v -> navigateBack());

        btnGenerate.setOnClickListener(v -> {
            if (validateInputs()) {
                generateReport();
            }
        });
    }

    private boolean validateInputs() {
        if (childId == null || childId.isEmpty()) {
            Toast.makeText(requireContext(),
                    "Error: Child ID not provided",
                    Toast.LENGTH_SHORT).show();
            return false;
        }

        if (spinnerMonths.getSelectedItem() == null) {
            Toast.makeText(requireContext(),
                    "Please select a time period",
                    Toast.LENGTH_SHORT).show();
            return false;
        }

        return true;
    }

    private void generateReport() {
        try {
            String selected = spinnerMonths.getSelectedItem().toString();
            int months = extractMonthsFromSelection(selected);

            // Use ReportGenerationHelper directly
            ReportGenerationHelper helper = new ReportGenerationHelper(requireContext(), childId);

            helper.generateReport(months, new ReportGenerationHelper.ReportCallback() {
                @Override
                public void onSuccess(File pdfFile) {
                    if (getContext() != null) {
                        Toast.makeText(getContext(),
                                "PDF saved: " + pdfFile.getAbsolutePath(),
                                Toast.LENGTH_LONG).show();

                        helper.openPdf(pdfFile);
                        navigateBack();
                    }
                }

                @Override
                public void onError(String errorMessage) {
                    if (getContext() != null) {
                        Toast.makeText(getContext(),
                                "Error: " + errorMessage,
                                Toast.LENGTH_SHORT).show();
                    }
                }
            });
        } catch (Exception e) {
            Toast.makeText(requireContext(),
                    "Error generating report: " + e.getMessage(),
                    Toast.LENGTH_SHORT).show();
        }
    }

    private int extractMonthsFromSelection(String selection) {
        // Extract the number from strings like "Past 3 months"
        String numericPart = selection.replaceAll("\\D+", "");
        if (numericPart.isEmpty()) {
            return defaultMonths; // Fallback to default
        }
        return Integer.parseInt(numericPart);
    }

    private void navigateBack() {
        if (getActivity() != null) {
            requireActivity().getSupportFragmentManager().popBackStack();
        }
    }

    /**
     * Interface for communicating report generation to parent activity
     */
    public interface ReportGenerationListener {
        void onGenerateReport(String childId, int months);
    }
}