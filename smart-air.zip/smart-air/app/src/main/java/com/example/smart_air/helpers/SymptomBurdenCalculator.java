package com.example.smart_air.helpers;

import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

/**
 * SymptomBurdenCalculator - Analyzes symptom burden over time
 * Counts "problem days" based on red/yellow zones and symptom severity
 */
public class SymptomBurdenCalculator {

    public interface BurdenCallback {
        void onCalculated(BurdenResult result);
        void onError(Exception e);
    }

    public static class BurdenResult {
        public int totalDays;
        public int problemDays;
        public int redDays;
        public int yellowDays;
        public int greenDays;
        public double problemDayPercentage;

        public String getFormattedPercentage() {
            return String.format("%.1f%%", problemDayPercentage);
        }
    }

    /**
     * Calculate symptom burden for a child over a date range
     */
    public static void calculateBurden(String childId,
                                       LocalDate fromDate,
                                       LocalDate toDate,
                                       BurdenCallback callback) {
        FirebaseFirestore db = FirebaseFirestore.getInstance();

        db.collection("dailycheckin")
                .document(childId)
                .collection("entries")
                .get()
                .addOnSuccessListener(querySnapshot -> {
                    BurdenResult result = new BurdenResult();
                    result.redDays = 0;
                    result.yellowDays = 0;
                    result.greenDays = 0;

                    for (DocumentSnapshot doc : querySnapshot.getDocuments()) {
                        String docId = doc.getId();
                        LocalDate entryDate;

                        try {
                            entryDate = LocalDate.parse(docId);
                        } catch (Exception e) {
                            continue; // Skip invalid date formats
                        }

                        // Filter by date range
                        if (entryDate.isBefore(fromDate) || entryDate.isAfter(toDate)) {
                            continue;
                        }

                        String zone = doc.getString("zoneColour");
                        if (zone == null) continue;

                        switch (zone.toLowerCase()) {
                            case "red":
                                result.redDays++;
                                break;
                            case "yellow":
                                result.yellowDays++;
                                break;
                            case "green":
                                result.greenDays++;
                                break;
                        }
                    }

                    result.totalDays = result.redDays + result.yellowDays + result.greenDays;
                    result.problemDays = result.redDays + result.yellowDays;

                    if (result.totalDays > 0) {
                        result.problemDayPercentage =
                                (result.problemDays * 100.0) / result.totalDays;
                    } else {
                        result.problemDayPercentage = 0.0;
                    }

                    callback.onCalculated(result);
                })
                .addOnFailureListener(callback::onError);
    }
}